<?php
/**
 * Silence is golden
 *
 * @package  jet-woo-product-gallery
 * @category Core
 * @author   Crocoblock
 * @license  GPL-2.0+
 */
