<?php
/**
 * Cart Totals Template
 */

woocommerce_cart_totals();
