<?php
/**
 * JetWooBuilder Single Reviews template.
 */

comments_template();
